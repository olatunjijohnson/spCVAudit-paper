## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(spLeakage)

## ----data---------------------------------------------------------------------
set.seed(21)
d <- data.frame(x = runif(120), y = runif(120))
d$z <- sin(3 * d$x) + rnorm(120, sd = 0.3)
folds <- sample(rep_len(1:5, nrow(d)))
g <- as.matrix(expand.grid(x = seq(0, 1, length.out = 10),
                          y = seq(0, 1, length.out = 10)))
target <- prediction_target(grid = g)

## ----spatial------------------------------------------------------------------
detect_leakage(d, folds, target, response = "z", coords = c("x", "y"))

## ----groups-------------------------------------------------------------------
dd <- rbind(d, d[1:10, ])  # deliberately copy complete observations
split <- sample(rep_len(1:5, nrow(dd)))
detect_group_leakage(dd, split, coords = c("x", "y"))
grouped <- group_kfold(dd, k = 5, coords = c("x", "y"))
detect_group_leakage(dd, grouped, coords = c("x", "y"))$frac_leaked

## ----features-----------------------------------------------------------------
d$covariate <- d$x + d$y + rnorm(nrow(d), sd = 0.1)
newdata <- data.frame(covariate = seq(1, 3, length.out = 100))
detect_feature_leakage(d, folds, covariates = "covariate", newdata = newdata)

## ----windows------------------------------------------------------------------
detect_extraction_leakage(d, folds, radius = 0.08, coords = c("x", "y"))

## ----temporal-----------------------------------------------------------------
st <- d[rep(1:20, each = 6), ]; st$time <- rep(1:6, 20)
st_folds <- sample(rep_len(1:5, nrow(st)))
detect_temporal_leakage(st, st_folds, time = "time")
forward <- temporal_kfold(st, k = 4, time = "time")
detect_temporal_leakage(st, forward, time = "time")$lookahead_frac

## ----spacetime----------------------------------------------------------------
detect_st_leakage(st, st_folds, time = "time", coords = c("x", "y"))

## ----trend--------------------------------------------------------------------
trend_strength(d, "z", coords = c("x", "y"))
audit_workflow(dd, split, target, response = "z", coords = c("x", "y"))

