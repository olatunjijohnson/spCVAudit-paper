## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 6, fig.height = 4)
library(spLeakage)

## ----data---------------------------------------------------------------------
set.seed(3)
n <- 160
centres <- matrix(runif(12, 0.1, 0.9), 6, 2)
xy <- centres[sample.int(6, n, replace = TRUE), ] +
  matrix(rnorm(2 * n, sd = 0.04), n, 2)
xy <- xy %% 2
xy[xy > 1] <- 2 - xy[xy > 1]
d <- data.frame(x = xy[, 1], y = xy[, 2])
D <- as.matrix(dist(xy))
Sigma <- 0.7 * exp(-D / 0.15) + diag(0.3, n)
d$z <- as.numeric(t(chol(Sigma)) %*% rnorm(n))
dep <- list(rho = function(h) 0.7 * exp(-h / 0.15),
            range = 0.15, practical_range = 0.45, signal_prop = 0.7)

## ----target-------------------------------------------------------------------
g <- seq(0.025, 0.975, length.out = 15)
target <- prediction_target(grid = as.matrix(expand.grid(x = g, y = g)))
folds <- sample(rep_len(1:5, n))
audit <- detect_leakage(d, folds, target, response = "z", dependence = dep,
                        coords = c("x", "y"))
audit

## ----ecdf, fig.alt="Validation and target nearest-neighbour distance distributions"----
plot(audit)

## ----contributions, fig.alt="Contributions to the signed correlation contrast"----
summary(audit)
plot(audit, which = "map")

## ----recommend----------------------------------------------------------------
recommend_validation(estimand = "prediction", design = "clustered", target = "grid")
recommend_validation(estimand = "population", design = "probability", target = "grid")

## ----rank---------------------------------------------------------------------
rank_cv_schemes(d, target, response = "z", coords = c("x", "y"))

