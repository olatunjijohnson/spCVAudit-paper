## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(spLeakage)

## ----example------------------------------------------------------------------
set.seed(18)
d <- data.frame(x = runif(120), y = runif(120))
d$z <- 2 * d$x - d$y + rnorm(120, sd = 0.4)
folds <- sample(rep_len(1:5, nrow(d)))
predict_linear <- function(train, test) {
  as.numeric(predict(lm(z ~ x + y, data = train), newdata = test))
}
comparison <- estimate_optimism(d, folds, response = "z", coords = c("x", "y"),
  control = "block", predict_fun = predict_linear)
comparison

